---
name: BioPrecision Enterprise
colors:
  surface: '#fbf9fb'
  surface-dim: '#dbd9dc'
  surface-bright: '#fbf9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f5'
  surface-container: '#efedf0'
  surface-container-high: '#e9e7ea'
  surface-container-highest: '#e3e2e4'
  on-surface: '#1b1c1e'
  on-surface-variant: '#44474d'
  inverse-surface: '#303032'
  inverse-on-surface: '#f2f0f3'
  outline: '#74777e'
  outline-variant: '#c4c6ce'
  surface-tint: '#4b607c'
  primary: '#00142b'
  on-primary: '#ffffff'
  primary-container: '#132943'
  on-primary-container: '#7c91b0'
  inverse-primary: '#b3c8e9'
  secondary: '#ac3500'
  on-secondary: '#ffffff'
  secondary-container: '#ff6f3b'
  on-secondary-container: '#611a00'
  tertiary: '#1f1000'
  on-tertiary: '#ffffff'
  tertiary-container: '#3a2301'
  on-tertiary-container: '#ac895c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d3e3ff'
  primary-fixed-dim: '#b3c8e9'
  on-primary-fixed: '#041c36'
  on-primary-fixed-variant: '#334863'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59d'
  on-secondary-fixed: '#390c00'
  on-secondary-fixed-variant: '#832600'
  tertiary-fixed: '#ffddb6'
  tertiary-fixed-dim: '#e8c08e'
  on-tertiary-fixed: '#2a1800'
  on-tertiary-fixed-variant: '#5d411b'
  background: '#fbf9fb'
  on-background: '#1b1c1e'
  surface-variant: '#e3e2e4'
  brand-navy-dark: '#0B1320'
  brand-navy-surface: '#132943'
  accent-orange-vibrant: '#FF5B00'
  surface-canvas: '#F8FAFC'
  surface-card: '#FFFFFF'
  border-subtle: '#E2E8F0'
  border-prominent: '#CBD5E1'
  status-success: '#0D9488'
  status-warning: '#D97706'
  status-danger: '#E11D48'
  status-info: '#0284C7'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.05em
  metric-display:
    fontFamily: Inter
    fontSize: 1.875rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an institutional, high-precision aesthetic tailored for pharmaceutical science, R&D computational biology, and enterprise AI leadership. The visual posture balances pharmaceutical clinical rigor with modern computational velocity. It replaces sprawling, unguided spreadsheets with dense, high-clarity telemetry surfaces, visual stage-gates, and structured card environments.

The visual style blends **Corporate / Modern** discipline with subtle **Minimalist Precision**:
- High-contrast clinical legibility anchored by a deep navy institutional ground.
- Targeted kinetic energy via the signature orange accent, reserved exclusively for active pipeline stages, primary actions, and critical notifications.
- Crisp border structures and subtle micro-tonal elevation rather than heavy drop shadows, ensuring dense data dashboards remain sharp, calm, and readable during protracted multi-hour research and governance reviews.

## Colors

The palette leverages a light enterprise canvas underpinned by deep institutional navy and energetic biocentric orange:

- **Primary (`#132943`)**: Anchor tone used for core typography, navigation chrome, high-emphasis header surfaces, and primary administrative framing. Provides commanding weight and stability.
- **Secondary (`#F36633`)**: The primary brand accent. Deployed with intentional restraint to highlight active pipeline gates, focal action triggers, KPI callouts, and key data milestones.
- **Surface Hierarchy**: `#F8FAFC` provides a neutral canvas tint that prevents harsh white glare, allowing white container cards (`#FFFFFF`) to stand out naturally against subtle slate borders (`#E2E8F0`).
- **Telemetry & Status Accents**: Distinct clinical semantic tokens—`#0D9488` (Stable/Active), `#D97706` (Gated/Review), `#E11D48` (Blocked/At-Risk), and `#0284C7` (Pilot/Discovery)—provide rapid cognitive decoding across pipeline cards without competing with the primary orange accent.

## Typography

Typography relies on a systematic, tabular-optimized deployment of **Inter** across all display, narrative, and operational tiers.

- **Tabular Figures (`tnum`)**: All numeric metrics, portfolio costs, pipeline durations, and stage markers must enforce tabular numeral spacing for effortless vertical scanning across tables and card arrays.
- **Display & Headlines**: Bold, tight letter-tracking (`-0.025em`) imparts structural authority and clinical directness without superfluous decorative flair.
- **Label Tokens**: Uppercase or semi-bold micro-labels (`label-sm`, `label-md`) are calibrated with expanded tracking (`0.02em` to `0.05em`) to ensure legibility when categorizing metadata attributes, data governance tiers, and pipeline gates.

## Layout & Spacing

The layout model implements a flexible, high-efficiency grid calibrated for data-dense portfolio administration:

- **Grid Architecture**: A 12-column responsive fluid grid structured with `1.5rem` (`24px`) gutters on desktop, compressing to `1rem` on mobile and tablet surfaces.
- **Rhythm**: All vertical and horizontal metrics conform to an uncompromising 4px/8px base modular unit.
  - `space-xs` (4px): Inner badge padding, icon-to-label inline offsets.
  - `space-sm` (8px): Filter chip gaps, compact button spacing, metric label offsets.
  - `space-md` (16px): Internal card cell padding, form input spacing, standard component margins.
  - `space-lg` (24px): Card headers, metric container gutters, stage-gate connectors.
  - `space-xl` (32px): Primary section divisions, filter bar vertical displacement.
- **Adaptive Reflow**:
  - **Desktop (≥1280px)**: Multi-column project card layouts (3 or 4 across), persistent sidebar navigation, dual-axis telemetry panels.
  - **Tablet (768px - 1279px)**: Two-column responsive card layouts, condensed collapsible filter rails.
  - **Mobile (<768px)**: Single-column linear flow, horizontal scrollable stage-gate trackers, sticky operational controls.

## Elevation & Depth

To maintain high data clarity and avoid muddy visuals during complex data navigation, visual depth relies primarily on **crisp structural borders** and **whisper-light ambient shadows**:

- **Ground Level (Canvas)**: `#F8FAFC`, a flat neutral ground establishing maximum tonal separation from elevated card containers.
- **Surface Elevation 1 (Cards, Tables, Panels)**: `#FFFFFF` filled surfaces paired with a crisp 1px border (`#E2E8F0`) and an ambient, low-opacity foundation shadow: `0 1px 3px 0 rgba(19, 41, 67, 0.05), 0 1px 2px -1px rgba(19, 41, 67, 0.03)`.
- **Surface Elevation 2 (Hovered Cards, Dropdown Drawers)**: Retains crisp borders while deepening the ambient drop: `0 4px 12px -2px rgba(19, 41, 67, 0.08), 0 2px 6px -2px rgba(19, 41, 67, 0.04)`.
- **Surface Elevation 3 (Modals, Stage-Gate Flyouts)**: `0 12px 28px -4px rgba(19, 41, 67, 0.12), 0 8px 10px -6px rgba(19, 41, 67, 0.06)`, anchored with a frosted slate backdrop blur (`backdrop-blur-sm` over `rgba(11, 19, 32, 0.4)`).
- **Subtle Glow & Accent Focus**: Form fields and selected cards on focus receive a refined `0 0 0 3px rgba(243, 102, 51, 0.15)` micro-ring, providing sharp interactive feedback without visual noise.

## Shapes

The design system enforces a restrained, institutional **Soft (`1`)** shape geometry:

- **Standard Elements (0.25rem / 4px)**: Default for input inputs, filter badges, data cells, tooltips, and linear stage-gate indicators. Reflects technical and laboratory precision.
- **Containers & Cards (`rounded-lg` / 0.5rem / 8px)**: Applied to project tiles, KPI stat boxes, modal windows, and flyout configuration panels. Softens the UI perimeter while keeping horizontal and vertical edge alignments crisp.
- **Pills / Status Chips**: Only operational status dots and condensed tag pills use continuous fully rounded edges (`rounded-full`) to immediately differentiate live categorical tags from structural interactive frames.

## Components

### Buttons
- **Primary**: Deep navy background (`#132943`), white label, crisp 4px radius. On hover, transitions to `#0B1320`.
- **Accent**: GSK brand orange (`#F36633`), white label, high-contrast action intent. Hover shifts to `#FF5B00`.
- **Secondary / Outline**: Transparent fill, 1px `#CBD5E1` border, `#132943` text. Hover state introduces `#F1F5F9` background.
- **Ghost**: Zero border, `#132943` text, used within dense table and card headers for tertiary utility operations.

### Cards & Project Tiles
- Built with a `#FFFFFF` base, 1px `#E2E8F0` border, and 8px border radius.
- **Card Header**: Hosts the project title, AI domain tag (e.g., *Genomics, Target Discovery*), and a high-visibility health indicator dot.
- **Card Body**: Displays key metric blocks (Data Velocity, Model Accuracy, Milestone Target) styled with `metric-display` typography alongside concise micro-labels.
- **Interactive State**: Border transitions to `#CBD5E1` with a soft ambient lift (`Elevation 2`) on hover.

### Pipeline Stage Visualizer
- A segmented linear progression bar depicting lifecycle stages (e.g., *Discovery → In Silico Validation → Pre-Clinical → Clinical AI*).
- **Completed**: `#132943` solid fill with trailing connective hairline.
- **Active / Current**: `#F36633` high-visibility accent fill paired with a subtle rhythmic pulse.
- **Upcoming**: `#E2E8F0` neutral fill with `#64748B` placeholder text.

### Filter & Query Bar
- High-efficiency horizontal control strip spanning the canvas width.
- Incorporates a segmented view-toggle button (Dashboard, Card Grid, Structured List), multi-select dropdown chips for therapeutic area and algorithm class, and an instant search input with a subtle slate-tinted active ring.

### Status Badges & Chips
- Compact padding (`0.25rem` vertical, `0.5rem` horizontal), micro-label typography (`0.75rem`), with a soft tinted background and high-contrast text:
  - *Active / On-Track*: Background `#CCFBF1`, text `#0F766E`.
  - *Stage Gate Review*: Background `#FEF3C7`, text `#B45309`.
  - *Blocked / Escalation*: Background `#FFE4E6`, text `#BE123C`.

### Form Inputs & Select Controls
- Clean white inputs with a 1px `#CBD5E1` baseline border and 4px corner radius.
- Height standardized to 36px for high data-density workspaces.
- Active focus state invokes an orange glow ring (`rgba(243, 102, 51, 0.2)`), signaling direct keyboard engagement.