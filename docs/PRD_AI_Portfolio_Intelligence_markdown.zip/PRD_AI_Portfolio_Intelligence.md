# PRD: AI Programme and Project Portfolio Intelligence

14 October 2026. Author: Meraj Akhtar, meraj@aiplanet.com

## Summary

GSK's Enterprise Data and AI organisation needs one intelligence layer over all its AI programmes and projects: where each one stands, what it depends on, what it costs, what it has delivered and whether it has been vetted. Today that picture is assembled by hand from Excel and SharePoint lists, there is no system of record, and the person who built the current version (Devon, portfolio and value enablement) adds capability weekly on her own.

The product is a stakeholder workspace plus a governed context layer on the Microsoft stack. The workspace gives AI leadership, sponsors, project leads and finance role-based views of delivery, releases, dependencies, cost, outcomes and governance, with every statement traceable to a source record. The context layer gives agents access to the right information in the right way, inside GSK's guardrails, which is the constraint Devon named as the hard problem.

**Problem statement.** Leadership cannot answer, from one place and with evidence, what the AI portfolio delivered this week, what is blocked and by whom, where spend is diverging, which benefits are measured rather than forecast, and which solutions have cleared governance. Business units work differently, Microsoft tenant policies block some standard approaches, and ownership between the portfolio office and the AI/ML engineering team is unsettled.

**Proposed product name.** AI Programme and Project Portfolio Intelligence. Primary user: the portfolio lead preparing a leadership review. Source documents: the v2 specification (screens S01 to S15) and the 9 October 2026 call notes.

## Goals, non-goals and success measures

**Goals**

1.  One authorised weekly snapshot of the whole AI portfolio, usable by leadership without rebuilding last week's context.

2.  Every portfolio statement resolves to a source record with a version, an owner and a date.

3.  Owners respond to findings inside the product, against the evidence version they were shown.

4.  Release availability, adoption and benefit are kept distinct, so what is usable is never confused with what is deployed or forecast.

5.  Governance vetting status and funding attribution are visible on every project.

6.  Weekly usable increments from week one, built on the lists GSK maintains today.

**Non-goals (first release)**

- Changing any source system. The product records decisions and routes requests; execution stays in the system of authority.

- Automatic investment ranking or funding optimisation. Comparison supports judgement; it does not rank.

- Critical-path or schedule-impact calculation until structured dependency data and an agreed method exist.

- Replacing GSK's project management or finance tools.

**Success measures**

| Measure                                                                   | Baseline (today)                          | Target after week 8                |
|---------------------------------------------------------------------------|-------------------------------------------|------------------------------------|
| Time for the portfolio lead to prepare the weekly leadership briefing     | About a day of manual assembly (reported) | Under two hours, from the snapshot |
| Share of portfolio statements with a resolvable evidence reference        | Not tracked                               | 100 percent of findings and totals |
| Owner responses recorded against a finding version within the review week | Not tracked                               | 80 percent of requested responses  |
| Projects with a visible governance vetting status                         | Partial, in a separate tracker            | 100 percent                        |
| Business units onboarded through configuration only                       | 1                                         | 2                                  |

## Users and roles

Sign-in is through the GSK Entra ID tenant. Role comes from directory group membership and is applied once, before any view, investigation or briefing, so the same access rules hold everywhere.

| Role                    | Who                                           | Lands on                                       | Can do                                                                                                                                                                          | Cannot do                             |
|-------------------------|-----------------------------------------------|------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------|
| Portfolio lead          | Portfolio and value enablement team           | Portfolio overview, all programmes             | Review findings, request responses, close the weekly review, prepare and publish briefings, apply definition changes, record reconciliation decisions, verify action completion | Change source systems                 |
| Sponsor                 | Programme sponsors, Chief Data and AI Officer | Programme detail for their programme           | Read assessments, record decisions, verify action completion, add items to a briefing                                                                                           | Apply definition changes              |
| Project lead            | Project and release owners                    | Project detail and their outstanding responses | Confirm, revise or challenge findings, update their actions, record release conditions, ask questions in their scope                                                            | Verify completion, publish briefings  |
| Finance                 | Finance business partners                     | Cost and outcome views                         | Confirm allocation bases, reconcile cost records, respond to cost findings                                                                                                      | Edit delivery or release records      |
| Reporting or data owner | Source owners                                 | Sources and quality                            | Confirm identifier mappings, request corrections, retry ingestion                                                                                                               | See data outside their source's scope |

Every screen keeps the selected portfolio, reporting date, comparison period and the user's permissions. A My work indicator shows each person the responses requested from them and the actions they own.

## Functional requirements by screen

Four navigation destinations (Portfolio, This week, Programmes and projects, Decisions and actions) plus Briefing, Ask, and two administrative views. The default perspective is Delivery, Releases, Dependencies, Cost, Outcomes; the default comparison is the latest snapshot against the last closed review.

| ID    | Screen                       | Requirement                                                                                                                                                                                                                                                                                                                                                                                                                                               | Acceptance                                                                                                      |
|-------|------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|
| FR-01 | S01 Portfolio overview       | Portfolio assessment, interactive position matrix (programmes expand to projects; grouping by programme or business area), prioritised findings with filters, history of material changes and open actions. A source update during review shows "New information available"; the user chooses when to refresh. Totals carry coverage and exclusions.                                                                                                      | A stakeholder can identify a material concern, see which work it affects and open its evidence directly         |
| FR-02 | S02 This week                | Weekly delivery timeline; discussion queue in five groups (completed, changes to understand, releases delivered or moved, decisions and responses required, carried forward); next-period view; meeting view; record a conclusion; close the review to create a snapshot, later corrections become amendments. Late-arriving items are labelled by event date and receipt date.                                                                           | The reviewer explains what changed, what is unresolved and what action is required without rebuilding last week |
| FR-03 | S03 Weekly releases          | Release briefing, timeline grouped by programme with distinct markers for planned, deployed, available, expanded and withdrawn; selected-release panel; availability and adoption shown apart with observation period; outstanding follow-ups; filters by programme, capability, owner, availability, unresolved condition. Each release counted once.                                                                                                    | A stakeholder explains what became usable this week, whether it met the commitment and what follow-up remains   |
| FR-04 | S04 Directory                | Search by name, objective, owner, capability, dependency or release; filters; server-side pagination; programme rows (objective, sponsor, projects, key commitment, material finding, freshness) and project rows (purpose, owner, commitment, release and cost position, outstanding response); summary panel; multi-select comparison tray with a focus of delivery, releases, cost or outcomes that preserves scope, period and definition differences | A stakeholder finds relevant work and compares appropriate evidence while each measure keeps its meaning        |
| FR-05 | S05 Programme detail         | Header (objective, sponsor, lead, reporting date, assessment, next decision); views for position, delivery, projects, dependencies, releases, cost and outcomes, decisions and history. Programme position is the worst contributing condition, never an average; missing project information stays visible                                                                                                                                               | The sponsor understands how projects contribute and where to intervene                                          |
| FR-06 | S06 Project detail           | Header with purpose, programme, owner, current commitment, reporting freshness and material unresolved finding; actions Ask, Add to briefing, Record owner response; governance gates; commitment timeline; scope-change history; technical issues as delivery-relevant records; dependencies; releases; cost and outcomes; history. Completion shown as completed commitments unless the client agrees a method                                          | A project lead or sponsor explains the delivery position and traces changes to records                          |
| FR-07 | S07 Release detail           | Capability, owner, projects, planned and actual availability, outstanding conditions; views for capability and availability, changes, adoption and feedback, evidence and follow-up; compare with previous release; withdrawn capability keeps history                                                                                                                                                                                                    | A stakeholder establishes what changed, who can use it and what has been observed since                         |
| FR-08 | S08 Dependency exploration   | Typed, dated, evidence-linked graph of programmes, projects, datasets, models, teams, services and outcomes; focus by project, owner, type or date; stable layout; accessible list alternative; side panel with actual impact, owner-reported impact and AI-inferred exposure shown separately; request clarification; create follow-up; reuse candidates flagged for owner assessment                                                                    | A stakeholder traces a constraint to affected work and the responsible owner                                    |
| FR-09 | S09 Finding panel            | Ordered: headline and affected work; reported fact, calculated result or AI interpretation; previous and current position; significance; evidence; unknowns; owner responses; next action. Confirm, revise, challenge with reason, request clarification, assign action. Responses record reviewer, date and evidence version; a changed version keeps the draft and shows the change; rejected interpretations stay in history                           | A stakeholder responds without confusing confirmation with approval to change a plan, budget or source          |
| FR-10 | S10 Evidence viewer          | Record or excerpt with source, date, version, owner and context; compare versions field by field; open the permitted original; flag an inconsistency; explicit handling of unavailable originals, broken anchors, stale records and permission limits                                                                                                                                                                                                     | The user identifies the exact basis, period and limitations of a statement                                      |
| FR-11 | S11 Contextual investigation | Ask from any programme, project, release, finding or visual; adjustable scope; seven default question types; visible run states (queued, retrieving, analysing, awaiting clarification, completed, failed, cancelled); refine, clarify or cancel; output with answer, method and inputs, evidence, uncertainties and proposed response; results routable to briefing or owner                                                                             | The user receives a traceable explanation or a clear account of what is still needed                            |
| FR-12 | S12 Decisions and actions    | Three views: responses required, decisions, actions; default to the user's own; aging rules; linked history from finding to decision to action; record response, assign, update progress, record blocker or completion evidence; owner-reported and verified completion distinct; reopen keeps history                                                                                                                                                    | A stakeholder determines what is required, who owns it and whether it happened                                  |
| FR-13 | S13 Briefing preparation     | Audience, scope, period and snapshot controls; selection tray; editable canvas with seven standard sections, reorder and edit; evidence and review-status panel; claims without support marked for substantiation; audience preview hides restricted content; draft, under review, approved, published, superseded; publication creates a versioned snapshot                                                                                              | The portfolio lead prepares a coherent briefing with evidence and owner responses intact                        |
| FR-14 | S14 Sources and quality      | Source list with supplies, owner, authoritative fields, cadence, last refresh, connection health and content quality shown separately; coverage map; problem view with affected records, conflicting values, dates, field authority, downstream effects and reconciliation owner; confirm mappings, record decisions, request correction, retry ingestion. A newer value never silently overrides an authoritative one                                    | An owner identifies an issue, understands its reporting impact and takes the corrective step                    |
| FR-15 | S15 Definitions              | Portfolio structure, delivery, release, financial and outcome definitions, source authority, review rules and briefing templates, each with version, owner, effective date and reason; preview the effect of a change against a snapshot before applying; past snapshots and briefings keep the definitions in force at the time                                                                                                                          | The reporting owner explains why a measure behaves as it does and the effect of changing it                     |

## Information and visual rules

These hold on every screen and are the reason the product can be trusted in a leadership review.

1.  Original commitment, current commitment and actual result are kept and shown separately.

2.  Reported position and AI interpretation are visibly distinct. Calculations return their inputs and method.

3.  Owner confirmation is recorded against a specific finding and evidence version, with its own indicator.

4.  Forecast benefits, measured outcomes, released capacity and cash savings are never summed together.

5.  Release availability is distinct from deployment and from adoption; a release is counted once.

6.  Missing, stale and conflicting information is shown explicitly, including inside programme assessments and totals (coverage and exclusions accompany every calculated total).

7.  Historical review snapshots are preserved; closing a review creates one, corrections create amendments.

8.  Programme totals use defined aggregation rules. Completion percentages are not averaged without an agreed method. Shared costs, releases and benefits are not double counted.

9.  Consequential actions on source systems stay within their designated authority; the workspace records, it does not execute.

10. Colour carries a defined condition: amber attention, red breached commitment or criterion, teal supported as meeting the requirement, neutral blue reported but not assessed, hatched grey insufficient information. A legend explains it wherever a condition appears.

11. Every complex visual has a list or table alternative; graphs keep stable positions while filtering; keyboard navigation, visible focus and reduced motion are part of the design contract.

12. Restrained navy navigation, a quiet reading surface, one type scale, dense data tables with right-aligned numbers.

## Core data model

The first implementation represents these records. Source event time and ingestion time are both kept, so historical reporting shows what was known at the review date.

| Record                  | Essential relationships and fields                                                                                                                                                                                                                                                               |
|-------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Programme               | Objectives, sponsor, lead, business area, projects, funding split by business unit, assessment, next decision                                                                                                                                                                                    |
| Project                 | Programme membership (exactly one, for counting), purpose, owner, lifecycle stage, position per dimension, current commitment, reporting freshness, governance gates, funding split                                                                                                              |
| Commitment or milestone | Baseline date, revisions, actual result, owner, status, evidence                                                                                                                                                                                                                                 |
| Scope change            | Affected work, what was added, removed or revised, date, owner-reported delivery effect, evidence                                                                                                                                                                                                |
| Business capability     | Intended users or processes, contributing projects, releases                                                                                                                                                                                                                                     |
| Release                 | Capability, project, previous release, dated events (planned, deployed, available, expanded, withdrawn), enabled teams, outstanding conditions, adoption observation, evidence                                                                                                                   |
| Dependency              | Type (requires an input, delivers a capability, depends on a team commitment, shares a service, contributes to an outcome), provider, consumer, required date, owner, position, actual impact, owner-reported impact, AI-inferred exposure, affected commitments, reuse candidate flag, evidence |
| Resource constraint     | Required team or skill, affected commitment, responsible owner                                                                                                                                                                                                                                   |
| Cost record             | Amount, currency, period, allocation basis, budget, actual or forecast, funded by                                                                                                                                                                                                                |
| Outcome measure         | Definition, population, baseline, forecast, measured value, kind (forecast benefit, measured outcome, released capacity, cash saving), attribution, owner, period, evidence                                                                                                                      |
| Finding                 | Statement type (reported fact, calculated result, AI interpretation), category, affected work, previous and current position, significance, evidence, unknowns, version, first seen, persistent flag, requested owner, due date, responses                                                       |
| Owner response          | Finding version, reviewer, date, action (confirmed, revised, challenged, clarification requested, action assigned), note                                                                                                                                                                         |
| Decision                | Question, conclusion, decision maker, date, conditions, authoritative reference, originating finding, resulting actions                                                                                                                                                                          |
| Action                  | Title, owner, due date, status (open, in progress, blocked, reported complete, verified complete), blocker, completion evidence, history                                                                                                                                                         |
| Source and evidence     | Provenance, timestamps, versions, permissions, anchors, previous field values                                                                                                                                                                                                                    |
| Snapshot                | Review period, date, status (open, closed, amended)                                                                                                                                                                                                                                              |
| Briefing                | Audience, scope, period, snapshot, status, version, sections with narrative and selected records                                                                                                                                                                                                 |
| Definition              | Area, name, value, version, owner, effective date, reason, what it affects                                                                                                                                                                                                                       |

Storage follows the relationship queries actually required. A graph visualisation does not need a graph database; Azure SQL with typed relationship tables is enough for the first implementation.

## Architecture

The recommended build is a governed context layer on Azure with agents on Azure AI Foundry, surfaced through two channels: this web workspace and a Copilot Studio agent in Teams. It fixes the data access problem once and gives both channels the same agents and the same audit trail.

![reference architecture on Microsoft: sources, context layer, agent runtime, channels](media/image1.png)

reference architecture on Microsoft: sources, context layer, agent runtime, channels

Sources as they are today feed one validated context store. Application services read authorised records from it and serve three channels. The orchestrator runs the investigation agent against scoped facts in the same store, so every answer resolves to the same evidence.

| Component                | Service                                           | Why this one                                                                                                                                                  |
|--------------------------|---------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Ingestion and validation | Microsoft Graph API, Fabric pipelines, Logic Apps | Reads the lists and sites GSK already maintains without moving them                                                                                           |
| Context and evidence     | Azure SQL (Fabric Lakehouse as an option)         | Typed records with versions, provenance and row-level permissions; one access decision for every agent                                                        |
| Application services     | App Service, Entra ID                             | Role filtering applied once, before any view, investigation or briefing                                                                                       |
| Orchestrator             | Durable Functions                                 | Persisted state, bounded retries, cancellation, no duplicate external actions on resume                                                                       |
| Investigation agent      | Azure AI Foundry Agent Service, AI Search         | Approved tools only (retrieve, compare, trace, calculate) with an audit trail                                                                                 |
| Conversational channel   | Copilot Studio agent in Teams                     | Quick questions and nudges where people already are; cards link into the workspace                                                                            |
| Stakeholder workspace    | React 19, TypeScript, MUI, TanStack Query         | Matrix, dependency graph, timelines, findings with owner responses, briefing preparation; the URL holds selection state so panels survive refresh and sharing |

**Routes considered.** Route A, Copilot Studio agents in Teams only: fastest to approve (1 to 2 weeks to a first release) but Adaptive Cards cannot carry a matrix, a graph or versioned findings, and version checks are custom work on Dataverse. Route B, a fully custom build on Azure Foundry and Graph: full capability but 4 to 6 weeks to a first release and a new approval path. The preferred hybrid lands a first release in 2 to 3 weeks by reading current SharePoint lists, then adds connectors weekly; the context layer and agents sit with AI/ML engineering, workspace configuration and definitions with the portfolio office.

## Sources and integrations

Each source is authoritative for named fields only. A newer value in one source never overwrites an authoritative value in another; conflicts go to a reconciliation owner.

| Source                                             | Supplies                                                               | Authoritative for                                 | Cadence                | Integration                          |
|----------------------------------------------------|------------------------------------------------------------------------|---------------------------------------------------|------------------------|--------------------------------------|
| AI Initiative Register (SharePoint list)           | Project identity, owner, stage, weekly status, current commitment date | Project ID, owner, stage, current commitment date | Weekly, Friday         | Graph API list read                  |
| Programme plans (Excel on Teams sites)             | Milestones, baseline and revised dates, scope changes                  | Baseline date, scope change record                | On change              | Graph API file read, Fabric pipeline |
| Finance actuals and forecast (cost centre export)  | Budget, actual, forecast by cost centre and period                     | Budget, actual, forecast, cost centre             | Monthly, working day 5 | Scheduled file drop, Logic App       |
| Copilot Studio release log and Teams app catalogue | Deployment events, publication, enabled security groups                | Deployed date, enabled group                      | Event driven           | Platform API                         |
| Governance intake tracker                          | Review requests, board decisions, turnaround                           | Review status, decision date                      | Weekly                 | SharePoint list read                 |
| Model registry (Azure AI Foundry)                  | Model versions, endpoints, consuming agents                            | Model version, endpoint                           | Daily                  | Foundry API                          |
| Benefits register (Excel)                          | Outcome definitions, baselines, forecasts, measurements                | Baseline, measured value, measurement owner       | Monthly                | Graph API file read                  |
| Data catalog                                       | Dataset ownership and lineage                                          | Dataset owner                                     | Daily                  | Catalog API                          |

Outbound: briefings exported as versioned snapshots to Teams or PowerPoint; Teams cards from the Copilot Studio agent link to workspace records. No writes to any source system in the first release.

## Non-functional requirements

| ID     | Area                       | Requirement                                                                                                                                                                                                     |
|--------|----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| NFR-01 | Identity                   | Entra ID single sign-on; role from directory groups; no local accounts                                                                                                                                          |
| NFR-02 | Permissions                | Views, investigations and briefings apply the same access rules; row-level filtering in the context layer; historical access subject to current permissions and retention                                       |
| NFR-03 | Audit                      | Every owner response, decision, action change, definition change, reconciliation decision and investigation run is recorded with user, time, evidence version and inputs                                        |
| NFR-04 | Agent safety               | Investigations use approved operations only, with requester permissions, context snapshot, permitted tools, execution limits and outputs recorded; no source-system writes                                      |
| NFR-05 | Concurrency                | Version checks on findings, actions and briefings; concurrent edits never silently overwrite; a changed evidence version is shown before a draft response is submitted                                          |
| NFR-06 | Recovery                   | Interrupted investigations and workflows resume from persisted state without repeating an external action; bounded retries; cancellation                                                                        |
| NFR-07 | Performance                | Overview, directory and detail screens render within 2 seconds on the tenant network for a portfolio of 200 projects; lists are paginated server-side; investigations return or report status within 60 seconds |
| NFR-08 | Accessibility              | WCAG 2.2 AA; every graph has a list or table alternative; keyboard operable; visible focus; reduced motion respected; colour never the only carrier of meaning                                                  |
| NFR-09 | Responsiveness             | Usable at 360 px wide; contextual panels become full-screen views on small screens                                                                                                                              |
| NFR-10 | Data residency and hosting | GSK Azure landing zone, private endpoints, tenant-approved regions; no data leaves the tenant                                                                                                                   |
| NFR-11 | Observability              | Application and ingestion telemetry in Azure Monitor; source freshness and failures surfaced in the product (Sources and quality)                                                                               |
| NFR-12 | Configuration              | Definitions, materiality, routing and briefing templates editable by the portfolio office without a deployment; each change versioned with owner, effective date and reason                                     |

## Delivery plan

Eight weekly releases, each usable on its own, matching the way the portfolio office already ships. Week one reads the lists GSK maintains today; each later week adds a connector and retires a manual field.

![eight weekly releases and the handover milestone](media/image2.png)

eight weekly releases and the handover milestone

Each week closes with the release in use by the portfolio office and a short note of what was retired from the manual process. Week 7 onboards a second business unit through configuration only, which is the test of the definitions model. Week 8 hands the context layer and agents to AI/ML engineering with permissions parity verified across views, investigations and briefings.

## Recommendations

1.  **Treat the context layer as the product.** Fund and staff it first. Agents, Teams and the workspace are consumers. This is the piece GSK does not have, and it is what removes Devon's blocker.

2.  **Run agents on Azure AI Foundry, not inside Copilot Studio.** One approved tool set, one audit trail, one footprint the AI/ML engineering team already owns. Keep Copilot Studio as the Teams front door.

3.  **Deliver the workspace as a web application with role-based views.** Teams cards link into it. Do not try to carry a matrix, a dependency graph or versioned findings in Adaptive Cards.

4.  **Start on the current SharePoint lists in week one.** Do not wait for a system of record. Each connector added retires a manual field, which is how the register becomes the record.

5.  **Keep definitions and materiality as configuration owned by the portfolio office.** Onboarding a second business unit should need no engineering change; test that in week 7.

6.  **Settle ownership before week 4.** Context layer and agents with AI/ML engineering; workspace configuration, definitions and reconciliation decisions with the portfolio office. Write it down.

7.  **Get a policy owner for agent-mediated access to derived clinical and finance data.** Without one, the first blocked dependency repeats on every project.

8.  **Do not add investment ranking, funding optimisation or critical-path calculation in the first release.** Evidence comparison and recording the existing decision process are the core; the rest can follow once the data supports it.

## Open questions

**For GSK (Devon, Madhu's team)**

- [ ] Does the AI/ML engineering team already have a context layer or an Azure Foundry footprint we should build on rather than stand up a new one?

- [ ] Who owns the policy decision on agent-mediated access to derived clinical and finance data?

- [ ] Which business unit goes second, so the configuration model is tested early?

- [ ] Who owns definitions and reconciliation decisions once the portfolio office and engineering split responsibilities?

- [ ] Is a Copilot Studio agent in Teams wanted from week 3, or should the workspace prove itself first?

- [ ] Which tenant policies currently block Graph connectors or generative answers, and who can grant exceptions?

- [ ] Is there an agreed project completion method, or do we keep showing completed commitments rather than a percentage?

- [ ] What is the allocation basis for shared costs (for example the context layer's contribution to R&D projects)?

**For the Akkodis and AI Planet team**

- [ ] Commercial shape: fixed eight-week delivery, or time and materials with weekly releases?

- [ ] Who from the practice stays with GSK after week 8, and in what capacity?

- [ ] Do we propose the hybrid route only, or present all three with the hybrid preferred? (This PRD presents all three.)

- [ ] Who at GSK signs off the PRD: the portfolio office alone, or jointly with AI/ML engineering?

## Risks and assumptions

| Risk                                                                                   | Effect                            | Mitigation                                                                                                                             |
|----------------------------------------------------------------------------------------|-----------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|
| Tenant guardrails block a planned connector or the Foundry agent                       | A weekly release slips            | Week 1 uses only Graph list reads already in use; every later connector has a manual fallback field until approved                     |
| Ownership between the portfolio office and AI/ML engineering stays unsettled           | Decisions stall, duplicate builds | Written split by week 4 (recommendation 6); PRD signed off by both                                                                     |
| Source data quality is worse than expected (missing weekly updates, conflicting dates) | Findings and totals carry gaps    | The product shows gaps explicitly rather than hiding them; Sources and quality gives owners the fix path                               |
| Business units reject a shared definition of delayed, breached or available            | Comparisons lose meaning          | Definitions are versioned configuration with effect preview; differences are shown, not averaged                                       |
| Investigation answers are trusted beyond their evidence                                | Wrong decisions                   | Every answer carries method, inputs, evidence and uncertainties; AI interpretations are labelled and never blended with reported facts |
| Weekly cadence overloads owners with response requests                                 | Responses stop arriving           | Materiality rules limit what becomes a finding; the My work view keeps each person's list short                                        |

**Assumptions**

- GSK provides read access to the AI Initiative Register, programme plans, finance export, release log, governance tracker and model registry within the first two weeks.

- An Azure landing zone with Azure SQL, App Service, Durable Functions and Azure AI Foundry is available or can be provisioned by week 3.

- The portfolio office remains the owner of definitions and briefing templates.

- No writes to source systems in the first release.

- Reporting currency is GBP; fiscal year FY26; reporting week closes Friday and the review runs Monday.

## Artifacts and deliverables

| Artifact                           | What it is                                                                                                                            | Where                                             |
|------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------|
| Application (hosted)               | The stakeholder workspace, all 15 screens, sign-in, role-based behaviour, running on a seeded context store                           | Hosted link shared in chat (private until shared) |
| Application source                 | React 19, TypeScript, MUI, TanStack Query; feature-first layout; README, ARCHITECTURE and AGENTS files; docs/approach.md              | portfolio-intelligence-react.zip                  |
| Approach and architecture document | What GSK told us, recommendation, the three routes, reference architecture, roles and flow, weekly plan, open questions               | Portfolio Intelligence: Approach and Architecture |
| This PRD                           | Requirements, rules, data model, architecture, sources, non-functional requirements, delivery plan, recommendations, questions, risks | This document                                     |
| Specification v2 (S01 to S15)      | The sales team's detailed screen specification, the source of the functional requirements above                                       | AI-first Portfolio Intelligence v2 (Word)         |
| Meeting record                     | MoM of the 9 October 2026 call with Devon                                                                                             | Sales team record                                 |

**How they fit.** The specification defines the screens. This PRD turns them into requirements with acceptance criteria, adds the rules, data model, architecture and plan, and lists what is still open. The approach document is the shorter piece for Devon and the AI/ML engineering team. The application is the working reference for every requirement in this PRD; its read and write API files are the only parts that change when the real context service is connected.
